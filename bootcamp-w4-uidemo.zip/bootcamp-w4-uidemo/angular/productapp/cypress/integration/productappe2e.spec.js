describe('My First Test', () => {
    it('Does not do much!', () => {
      expect(true).to.equal(true)
    })
  })

  describe('Land in home page',()=>{

    it('Visits the home page',()=>{
        cy.visit("/")
    })
  })

  describe('login page',()=>{
   it('should reach login page',()=>{

// cy.location().should( (location)=> expect(location.href).to.equal('http://localhost:4200/login'))

cy.url().should('include','login');
cy.wait(3000);

   })

   it('should check h2',()=>{

    cy.get('.clsh2').contains('Login Form');
  cy.wait(4000);


   })
  })

  describe ('should check for login',()=>{

    it('should enter content in login ',()=>{

      //  cy.get('input[id=username]').type("admin");

  cy.get(".clsuser").type('admin');
  cy.get('.clspass').type('password');
  cy.wait(4000);
cy.get('.clssubmit').click();
cy.wait(4000);  
cy.location().should( (location)=>expect(location.href).to.eq('http://localhost:4200/dashboard/view/grid'));
    })

describe('should check for matexpansion pane',()=>
{

    it('check gridview button available',()=>{

        cy.get('.clsgrid').contains('Grid View');
        cy.wait(2000);
  
        })

   it('check matexpansion',()=>{
   cy.get('.clsmatexpansion').click();
cy.wait(3000);

  })

   it('check content of form',()=>{
  cy.get("#pid").type("0074");

  cy.get("#name").type("Fan").should('have.value',"Fan");

  cy.get("#descri").type("cpu fan").should('have.value',"cpu fan");

  cy.get("#price").type(6000);
 cy.wait(3000);
cy.get("#btnadd").click();

 cy.wait(2000);
   })

   it('check whether element added',()=>{
    cy.get('.clsmatcard .clsitemname').last().should('contain',"Fan")

cy.wait(1000);
   })


})




  })