import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthorizeService } from '../authorize.service';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-loginuser',
  templateUrl: './loginuser.component.html',
  styleUrls: ['./loginuser.component.css']
})
export class LoginuserComponent implements OnInit {

  userprofile : FormGroup;
  constructor(private authserve : AuthorizeService,private myroute : MyrouteService ) {
 

    this.userprofile=new FormGroup({
      emailid : new FormControl('',Validators.required),
      password: new FormControl('',Validators.minLength(5)),
      
      
      
      });
   }

  ngOnInit(): void {
  }



  signIn()
  {
  
   
   this.authserve.connectToserver(this.userprofile.value).subscribe
   (
     (res)=> {
      
        this.authserve.storeToken(res["token"]);

        console.log(res);
        this.myroute.openDashboard();
        

     }
   )
   
  
  }

}
