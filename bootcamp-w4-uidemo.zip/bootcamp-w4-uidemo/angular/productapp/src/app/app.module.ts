import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
 
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {ReactiveFormsModule} from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import {HttpClientModule} from '@angular/common/http';
import { DashboardComponent } from './dashboard/dashboard.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatDialogModule} from '@angular/material/dialog'
import {MatCardModule} from '@angular/material/card';
import {FormsModule} from '@angular/forms';


import {RouterModule, Routes} from '@angular/router';
import { CanactivatedashGuard } from './canactivatedash.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ProducttakerComponent } from './producttaker/producttaker.component';
import { GridviewComponent } from './gridview/gridview.component';
import { ListviewComponent } from './listview/listview.component';
import { CardproductComponent } from './cardproduct/cardproduct.component';
import { HeaderComponent } from './header/header.component';
import { ProducteditopenerComponent } from './producteditopener/producteditopener.component';
import { ProducteditdialogComponent } from './producteditdialog/producteditdialog.component';
import { SampletestComponent } from './sampletest/sampletest.component';
import { LoginuserComponent } from './loginuser/loginuser.component';
import { SpringdashboardComponent } from './springdashboard/springdashboard.component';
import { RegisteruserComponent } from './registeruser/registeruser.component';
const routes: Routes =[
  {
    path:'login',
    component:LoginComponent
    
  },
  {
    path:'loginnew',
    component:LoginuserComponent
  },
  {
    path:'newdashboard',
    component:SpringdashboardComponent
  },
 
  {
    path:'dashboard',
    component:DashboardComponent,
   canActivate:[CanactivatedashGuard],
   children:
   [
       {
         path:'view/grid',
         component:GridviewComponent
       },
       {
         path:'view/list',
         component:ListviewComponent
       },
       {
        path:'product/:pid/edit',
        component:ProducteditopenerComponent,
        outlet:'productEditoutlet'

      },
       {
         path:'',
         redirectTo:'view/grid',
         pathMatch:'full'
       },
       
   ]
   
  },
  {
    path:'',
    redirectTo:'loginnew',
    pathMatch:'full'
  }
  
  
  ]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    ProducttakerComponent,
    GridviewComponent,
    ListviewComponent,
    CardproductComponent,
    HeaderComponent,
    ProducteditopenerComponent,
    ProducteditdialogComponent,
    SampletestComponent,
    LoginuserComponent,
    SpringdashboardComponent,
    RegisteruserComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    MatExpansionModule,
    MatCardModule,
    MatFormFieldModule,
    MatToolbarModule,
    BrowserAnimationsModule,MatDialogModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
