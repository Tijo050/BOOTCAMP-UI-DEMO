import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SampletestComponent } from './sampletest.component';
import { By } from '@angular/platform-browser';
import { MatToolbarModule } from '@angular/material/toolbar';

import { EmployeeprocessService } from '../employeeprocess.service';

fdescribe('SampletestComponent', () => {
  let component: SampletestComponent;
  let fixture: ComponentFixture<SampletestComponent>;
  let sampledata={ employee :{"companyname" : "IBM","location":"chennai","empname":"Mary"}}

  beforeEach(async () => {
  
    await
    
    TestBed.configureTestingModule({
      declarations: [ SampletestComponent ],
      imports : [MatToolbarModule],
      providers :[{provide:EmployeeprocessService,useValue:sampledata}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SampletestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should check h1',()=>{
  let hobj=    fixture.debugElement.query(By.css(".clsh1"));
expect(hobj).toBeTruthy();
  });

  it('mat toolbar should exist',()=>{
let matobj=fixture.debugElement.query(By.css('mat-toolbar'));
expect(matobj).toBeTruthy();
}); 


it('mat toolbar content checking',()=>{
  let matobj=fixture.debugElement.query(By.css('mat-toolbar'));

  expect(matobj.nativeElement.textContent).toEqual('USTG');

  });


it('Should check existence of done button',()=>{

  let butobj=fixture.debugElement.query(By.css('.clsbut'));
  expect(butobj.nativeElement.textContent).toEqual("Done");
});

it('Should check name is displayed in span',()=>{
component.name="Dan";
fixture.detectChanges();
let spaobj=fixture.debugElement.query(By.css('#spauser'));
expect(spaobj).toBeTruthy();
expect(spaobj.nativeElement.textContent).toEqual("Hai Dan");
});

it('should inject employee service',()=>{

   let sobj=fixture.debugElement.injector.get(EmployeeprocessService);

let output=fixture.debugElement.query(By.css('.clsdiv'));
fixture.detectChanges();
expect(output.nativeElement.textContent).toEqual('Company is IBM','expecting company name to be displayed');

})


});//describe
