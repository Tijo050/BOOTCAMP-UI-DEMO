import { Component, OnInit } from '@angular/core';
import { EmployeeprocessService } from '../employeeprocess.service';

@Component({
  selector: 'app-sampletest',
  templateUrl: './sampletest.component.html',
  styleUrls: ['./sampletest.component.css']
})
export class SampletestComponent implements OnInit {

  name :string="";
company :string="";

  constructor(private empserve : EmployeeprocessService) { }

  ngOnInit(): void {

    this.company=this.empserve.employee.companyname;
  }

}
