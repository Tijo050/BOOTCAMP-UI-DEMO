import { Component, OnInit } from '@angular/core';
import { BillService } from '../bill.service';
import { Bill } from 'bill';

@Component({
  selector: 'app-springdashboard',
  templateUrl: './springdashboard.component.html',
  styleUrls: ['./springdashboard.component.css']
})
export class SpringdashboardComponent implements OnInit {

  bills : Array<Bill>=[];
  constructor(private billservice : BillService) { }

  ngOnInit(): void {
    this.showitems();
  }

  showitems()
  {
this.billservice.viewproducts().subscribe(

  res=> {this.bills=res;
    console.log(res);
    }
)
  }

}
