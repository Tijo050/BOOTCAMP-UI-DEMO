import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpringdashboardComponent } from './springdashboard.component';

describe('SpringdashboardComponent', () => {
  let component: SpringdashboardComponent;
  let fixture: ComponentFixture<SpringdashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpringdashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpringdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
