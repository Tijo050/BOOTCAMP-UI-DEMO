import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MyrouteService } from '../myroute.service';
import { ProductprocessService } from '../productprocess.service';
import { Product } from 'src/product';

@Component({
  selector: 'app-producteditdialog',
  templateUrl: './producteditdialog.component.html',
  styleUrls: ['./producteditdialog.component.css']
})
export class ProducteditdialogComponent implements OnInit,OnDestroy {
   product : Product=new Product();
   pid : any;
  constructor(private mydialog : MatDialogRef<ProducteditdialogComponent>,
    @Inject(MAT_DIALOG_DATA) private data :any,private myroute : MyrouteService,
    private prodservice : ProductprocessService)
  {

  }
  ngOnInit(): void {
  this.pid=this.data.myproductid;
 this.product= this.prodservice.findProductbyId(this.pid);
  
  }
  update()
  {
    this.prodservice.updateProduct(this.product).subscribe( e=>console.log("updated"));
    this.mydialog.close();
  }

  close()
  {
  this.mydialog.close();
  }

   ngOnDestroy():void{
     this.myroute.routetoback();
   }

}
