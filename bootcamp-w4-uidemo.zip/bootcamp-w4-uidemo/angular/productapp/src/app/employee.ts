export class Employee
{
     companyname: string="";
     location : string="";
     empname :string="";
constructor()

{
    this.companyname="Stackroute";
    this.location="BLore";
    this.empname="Mary";
}

}