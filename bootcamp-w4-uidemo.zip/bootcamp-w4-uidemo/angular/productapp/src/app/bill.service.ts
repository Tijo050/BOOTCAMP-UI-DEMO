import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthorizeService } from './authorize.service';
import { Observable } from 'rxjs';
import { Bill } from 'bill';

@Injectable({
  providedIn: 'root'
})
export class BillService {




  constructor(private httpcli : HttpClient,private authservice : AuthorizeService)
   { }



  viewproducts() : Observable<Array<Bill>>
  {

 let tok=this.authservice.getToken();
 
 return    this.httpcli.get<Array<Bill>>('http://localhost:9096/product/bill/viewallbills',
 {
  headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
}
 
 
 );
  }
}
