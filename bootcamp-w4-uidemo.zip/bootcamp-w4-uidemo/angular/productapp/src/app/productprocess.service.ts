import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { Product } from 'src/product';
import { AuthorizeService } from './authorize.service';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

// add data,delete, update by provding token
export class ProductprocessService {

  resultproduct : Product=new Product();
  products : Array<Product>=[];
  productsubject: BehaviorSubject<Array<Product>>;


  constructor(private httpcli : HttpClient,private authservice : AuthorizeService) { 

    this.productsubject=new BehaviorSubject<Array<Product>>([]);

  }


  fetchDatafromServer()
  {
    let tok=this.authservice.getToken();
    return this.httpcli.get<Array<Product>>('http://localhost:3000/api/v1/products',
    {
     headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
   }
   ).subscribe(

    (res)=>{
            this.products=res;
            this.productsubject?.next(this.products);
    },

    (err)=>
       this.productsubject?.error(err)
   )

  }

  addProduct(productobj : Product) : Observable<Product>
  {
    let tok=this.authservice.getToken();

  return  this.httpcli.post<Product>('http://localhost:3000/api/v1/products',productobj,
  {
    headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
  }
  ).
  pipe(

     tap( (nproduct:Product) =>
      {
        this.products.push(nproduct);
        this.productsubject.next(this.products);
      //  return this.productsubject
      }
  )
  );
  }

  getProducts() : BehaviorSubject<Array<Product>>
  {
  return this.productsubject;  
  }
  
   deleteProduct(id : any)
   {
    let tok=this.authservice.getToken();

    return  this.httpcli.delete(`http://localhost:3000/api/v1/products/${id}`,
    {
      headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
    }
    ).pipe(
      tap(()=>
      {
       const ind=this.products.findIndex( product=>product.id==id);
       this.products.splice(ind,1);
    this.productsubject.next(this.products);    
      }
      )
    );
   }

   updateProduct(prdchange : Product)
   {

    let tok=this.authservice.getToken();

    return  this.httpcli.put(`http://localhost:3000/api/v1/products/${prdchange.id}`
    ,prdchange,
    {
      headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
    }
    ).pipe(
      tap(
        (updatedprd)=>
      {
       let currele=this.products.find( product=>product.id===prdchange.id);
Object.assign(currele,updatedprd);

    this.productsubject.next(this.products);    
      }
      )
    );

   }

    findProductbyId(id : any) : any
    {

 
 const result=this.products.find( prd=> prd.id==id);
 return result;
    }

}
