import { Component, OnInit } from '@angular/core';
import { Product } from 'src/product';
import { ProductprocessService } from '../productprocess.service';

@Component({
  selector: 'app-producttaker',
  templateUrl: './producttaker.component.html',
  styleUrls: ['./producttaker.component.css']
})
export class ProducttakerComponent implements OnInit {

  errmessage:string="";
  product : Product=new Product();
  products : Array<Product>=[];
  constructor(private prodservice : ProductprocessService) { }
  
  ngOnInit(): void {
  }

  additem()
  {
     this.prodservice.addProduct(this.product).subscribe(
       res=>
       {
   //      this.products.push(res)
           
       }
     );

  }

}
