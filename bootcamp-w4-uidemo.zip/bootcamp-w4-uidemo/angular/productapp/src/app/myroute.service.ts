import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {Location} from '@angular/common'

@Injectable({
  providedIn: 'root'
})
export class MyrouteService {

  constructor(private myroute : Router,private location : Location) { }
  openLogin()
  {
    this.myroute.navigate(['login']);

  }
  openDashboard()
  {
    this.myroute.navigate(['newdashboard']);
  }

  openGridview()
  {
    this.myroute.navigate(['dashboard/view/grid']);
  }
  openListView()
  {
    this.myroute.navigate(['dashboard/view/list']);
  }
  openEditProduct(productid:any)
  {
    this.myroute.navigate(['dashboard',
    {
     outlets: { productEditoutlet: ['product',productid,'edit']}}
  ]);

  // dashboard/product/value/edit

  }

  routetoback()
  {
this.location.back();
  }

}
