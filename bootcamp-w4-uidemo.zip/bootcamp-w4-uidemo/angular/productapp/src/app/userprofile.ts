export class Userprofile
{
emailid : string="";
password : string="";


}