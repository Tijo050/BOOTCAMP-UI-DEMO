import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthorizeService } from '../authorize.service';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-registeruser',
  templateUrl: './registeruser.component.html',
  styleUrls: ['./registeruser.component.css']
})
export class RegisteruserComponent implements OnInit {
  userprofile : FormGroup;
  constructor(private authserve : AuthorizeService,private myroute : MyrouteService ) {
 

    this.userprofile=new FormGroup({
      emailid : new FormControl('',Validators.required),
      password: new FormControl('',Validators.minLength(5)),
      
      
      
      });
   }

  ngOnInit(): void {
  }

  store()
  {
  
   
   this.authserve.adduser(this.userprofile.value).subscribe
   (
     (res)=> {
      
        
        console.log(res);

     }
   )
   
  
  }

}
