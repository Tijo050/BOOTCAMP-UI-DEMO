import { Component, OnInit } from '@angular/core';
import { Product } from 'src/product';
import { ProductprocessService } from '../productprocess.service';

@Component({
  selector: 'app-listview',
  templateUrl: './listview.component.html',
  styleUrls: ['./listview.component.css']
})
export class ListviewComponent implements OnInit {

  product : Product=new Product();
  products : Array<Product>=[];
  
  producthardware : Array<Product>=[];
  productsware : Array<Product>=[];

  constructor(private prodservice : ProductprocessService) { }

  ngOnInit(): void {
    this.viewitem();
  }


  viewitem()
  {
     this.prodservice.getProducts().subscribe(
       res=> 
        { 
          this.filterdata(res)
        }
     )
  }

  filterdata( results : Array<Product>)
  {
    this.producthardware=results.filter( (prd)=>prd.description==="Hardware");
    this.productsware=results.filter( (prd)=>prd.description==="Software");
  }


}
