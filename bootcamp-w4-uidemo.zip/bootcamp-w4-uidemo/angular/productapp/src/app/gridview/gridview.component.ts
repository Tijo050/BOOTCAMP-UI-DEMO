import { Component, OnInit } from '@angular/core';
import { Product } from 'src/product';
import { ProductprocessService } from '../productprocess.service';

@Component({
  selector: 'app-gridview',
  templateUrl: './gridview.component.html',
  styleUrls: ['./gridview.component.css']
})
export class GridviewComponent implements OnInit {

  product : Product=new Product();
  products : Array<Product>=[];
  
  constructor(private prodservice : ProductprocessService) { }

  ngOnInit(): void {
    this.viewitem();
  }


  viewitem()
  {
     this.prodservice.getProducts().subscribe(
       res=> this.products=res
     )
  }

}
