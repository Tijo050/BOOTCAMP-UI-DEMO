import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ProducteditdialogComponent } from '../producteditdialog/producteditdialog.component';

@Component({
  selector: 'app-producteditopener',
  templateUrl: './producteditopener.component.html',
  styleUrls: ['./producteditopener.component.css']
})
export class ProducteditopenerComponent implements OnInit {

  productid :any;
  constructor(private myroute : ActivatedRoute,private dialog: MatDialog) { 
     this.productid=this.myroute.snapshot.paramMap.get('pid');

  this.dialog.open(ProducteditdialogComponent,{
    data : {myproductid : this.productid}
  });
  }
          
  ngOnInit(): void {
  }

}
