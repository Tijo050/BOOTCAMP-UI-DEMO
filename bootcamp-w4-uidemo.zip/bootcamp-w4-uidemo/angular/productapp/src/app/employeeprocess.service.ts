import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeprocessService {
employee : Employee;
  constructor() {
    this.employee=new Employee();
   }

   getcompanyName()
   {
     return this.employee.companyname;
   }



}
