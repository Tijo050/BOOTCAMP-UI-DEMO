import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/product';
import { ProductprocessService } from '../productprocess.service';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-cardproduct',
  templateUrl: './cardproduct.component.html',
  styleUrls: ['./cardproduct.component.css']
})
export class CardproductComponent implements OnInit {


  @Input()
  productobj : Product=new Product();

  constructor(private prodserv : ProductprocessService,
    private myroute: MyrouteService) { }

  ngOnInit(): void {
  }
  delete()
  {

    this.prodserv.deleteProduct(this.productobj.id).subscribe
    (
      res=>console.log("deleted")
     

    );
   // window.location.reload();


  }
  openeditView()
  {
   this.myroute.openEditProduct(this.productobj.id);

  }





}
