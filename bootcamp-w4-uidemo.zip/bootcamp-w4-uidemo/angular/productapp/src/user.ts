export class  User{
    emailid:string="";
    username :string ="";
    password: string ="";
    address : string ="";
    constructor(){}
}