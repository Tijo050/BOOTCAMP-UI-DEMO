export class Bill
{
    billnumber : string ="";
    customername : string ="";
}