import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule, Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { CompanyComponent } from './company/company.component';
import { EmployeeComponent } from './employee/employee.component';
import { VendorComponent } from './vendor/vendor.component';
import { MyangularComponent } from './myangular/myangular.component';
import { MyprojectComponent } from './myproject/myproject.component';
import { UstguardGuard } from './ustguard.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UstuserModule } from './ustuser/ustuser.module';
import { ModrouteModule } from './modroute/modroute.module';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    DashboardComponent,
    HomeComponent,
    CompanyComponent,
    EmployeeComponent,
    VendorComponent,
    MyangularComponent,
    MyprojectComponent
  ],
  imports: [
    BrowserModule,
     BrowserAnimationsModule,
    UstuserModule,
    ModrouteModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
