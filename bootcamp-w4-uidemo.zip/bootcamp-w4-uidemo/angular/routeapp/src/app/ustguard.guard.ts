import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { UstrouteService } from './ustroute.service';

@Injectable({
  providedIn: 'root'
})
export class UstguardGuard implements CanActivate {

constructor(private rouobj:UstrouteService)
{}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): 
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree 
    
    {
      let user=sessionStorage.getItem("username");
      let pwd=sessionStorage.getItem("password");

      if ((user===null) || (pwd!=="june"))
      {
this.rouobj.openLogin();
    return false;

      }
      return true;
  }
  
}
