import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UstrouteService {

  constructor(private rouobj : Router) { 

  }

  openLogin()
  {
    this.rouobj.navigate(['login']);
  }

  openDashboard()
  {
    this.rouobj.navigate(['dashboard']);
  }

  openHome()
  {
    this.rouobj.navigate(['home']);
  }

  openVendor()
  {
    this.rouobj.navigate(['dashboard/vendor']);
  }


  openEmployee()
  {
    this.rouobj.navigate(['dashboard/employee']);
  }
openangular()
{
  this.rouobj.navigate(['home/angular']);
}

openProject()
{
  this.rouobj.navigate(['home/project'])
}

}
