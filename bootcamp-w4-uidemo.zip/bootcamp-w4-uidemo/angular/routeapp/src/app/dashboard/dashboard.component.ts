import { Component, OnInit } from '@angular/core';
import { UstrouteService } from '../ustroute.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private rouserv : UstrouteService) { }

  ngOnInit(): void {
  }

  showemp()
  {
 this.rouserv.openEmployee();
  }

  showvendor()
  {
this.rouserv.openVendor();
  }

  signout()
  {
    sessionStorage.clear();
    this.rouserv.openHome();
  }

}
