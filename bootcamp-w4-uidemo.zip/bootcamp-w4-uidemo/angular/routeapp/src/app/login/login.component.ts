import { Component, OnInit } from '@angular/core';
import { UstrouteService } from '../ustroute.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private routobj : UstrouteService) { }

  ngOnInit(): void {
  }

  showDash(uname :string,pwd : string)
  {
sessionStorage.setItem("username",uname);
sessionStorage.setItem("password",pwd);
    alert("welcome " + uname + "password is " + pwd );
    this.routobj.openDashboard();
  }

}
