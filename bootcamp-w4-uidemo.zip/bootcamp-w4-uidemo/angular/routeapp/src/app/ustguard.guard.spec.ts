import { TestBed } from '@angular/core/testing';

import { UstguardGuard } from './ustguard.guard';

describe('UstguardGuard', () => {
  let guard: UstguardGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(UstguardGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
