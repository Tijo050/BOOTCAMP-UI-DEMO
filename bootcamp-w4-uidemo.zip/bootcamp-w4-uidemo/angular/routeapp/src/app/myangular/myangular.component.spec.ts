import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyangularComponent } from './myangular.component';

describe('MyangularComponent', () => {
  let component: MyangularComponent;
  let fixture: ComponentFixture<MyangularComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyangularComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyangularComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
