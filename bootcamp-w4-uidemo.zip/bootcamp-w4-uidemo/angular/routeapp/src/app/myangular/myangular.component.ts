import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myangular',
  templateUrl: './myangular.component.html',
  styleUrls: ['./myangular.component.css']
})
export class MyangularComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
