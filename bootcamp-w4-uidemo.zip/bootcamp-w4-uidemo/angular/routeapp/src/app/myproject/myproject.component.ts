import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myproject',
  templateUrl: './myproject.component.html',
  styleUrls: ['./myproject.component.css']
})
export class MyprojectComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
