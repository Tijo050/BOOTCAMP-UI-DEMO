import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from '../login/login.component';
import { HomeComponent } from '../home/home.component';
import { MyangularComponent } from '../myangular/myangular.component';
import { MyprojectComponent } from '../myproject/myproject.component';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { UstguardGuard } from '../ustguard.guard';
import { EmployeeComponent } from '../employee/employee.component';
import { VendorComponent } from '../vendor/vendor.component';

const myroute: Routes =[
  {
    path:'login',
    component:LoginComponent
    
  },
  {
    path:'home',
    component:HomeComponent,
    children:[
  {
    path:'angular',
    component:MyangularComponent
  
  },
  {
   path:'project',
   component:MyprojectComponent
  }
  
    ]
  
  },
  {
    path:'dashboard',
    component:DashboardComponent,
    canActivate:[UstguardGuard],
    children:
    [
      {
        path: 'employee',
        component:EmployeeComponent
      },
      {
        path:'vendor',
        component:VendorComponent
      }
    ]
  },
  {
    path:'',
    redirectTo:'home',
    pathMatch:'full'
  }
  
  
  ]
  
  


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule,
    RouterModule.forRoot(myroute),
  ],
  exports:[RouterModule]
}
)
export class ModrouteModule { }
