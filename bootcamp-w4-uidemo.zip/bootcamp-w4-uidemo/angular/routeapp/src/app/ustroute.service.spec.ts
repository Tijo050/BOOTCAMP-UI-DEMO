import { TestBed } from '@angular/core/testing';

import { UstrouteService } from './ustroute.service';

describe('UstrouteService', () => {
  let service: UstrouteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UstrouteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
