export class Item
{
     id:string="";
     itemname:string="";
     itemprice:number=0;
     constructor()
     {}

}