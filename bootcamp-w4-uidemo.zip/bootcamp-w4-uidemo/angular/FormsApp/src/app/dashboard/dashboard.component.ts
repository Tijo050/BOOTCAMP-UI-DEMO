import { Component, OnInit } from '@angular/core';
import { MathFunService } from '../math-fun.service';
import { EmpdataService } from '../empdata.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
 
})
export class DashboardComponent implements OnInit {

  constructor(private myservice : MathFunService,private empobj : EmpdataService)  //injecting service to component
    {

     }

  ngOnInit(): void {
  }

showDetails()
{
 this.empobj.showemployee("testing");
}

  display()
  {
    this.myservice.squareIt(4);
  }

}
