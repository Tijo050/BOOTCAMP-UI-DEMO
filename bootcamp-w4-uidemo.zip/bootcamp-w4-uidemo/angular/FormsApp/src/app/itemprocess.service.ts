import { Injectable } from '@angular/core';
import { Item } from 'src/item';

@Injectable({
  providedIn: 'root'
})
export class ItemprocessService {



 findTax(itemobj : Item)
 {
  let tax : Number;
 

    if(itemobj.itemprice>200)
     tax=itemobj.itemprice*26/100;
    else
       tax=itemobj.itemprice*18/100;



    alert("Commerical tax is " + tax);
 }

  constructor() { }
}
