import { TestBed } from '@angular/core/testing';

import { ItemprocessService } from './itemprocess.service';

describe('ItemprocessService', () => {
  let service: ItemprocessService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ItemprocessService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
