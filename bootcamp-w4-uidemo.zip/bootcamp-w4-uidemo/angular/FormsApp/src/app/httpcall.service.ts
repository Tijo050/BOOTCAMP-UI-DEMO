import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Item } from 'src/item';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpcallService {

  //items : Array<Item> =[];
  
  constructor(private httpcliobj : HttpClient) { }

getItemdetails() : Observable<Array<Item>>
{
 return this.httpcliobj.get<Array<Item>>("http://localhost:3000/item");
}

}
