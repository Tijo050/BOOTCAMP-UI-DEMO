import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MathFunService {

  constructor() { }

  squareIt(num :number)
  {
    alert(num*num);
  }
  
}
