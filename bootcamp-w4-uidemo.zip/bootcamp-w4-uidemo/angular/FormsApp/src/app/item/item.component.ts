import { Component, OnInit } from '@angular/core';
import { Item } from 'src/item';
import { ItemprocessService } from '../itemprocess.service';
import { HttpcallService } from '../httpcall.service';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {

  itemnew : Item;
  constructor(private itmservice:ItemprocessService,private httpobj : HttpcallService) {
    this.itemnew=new Item();
   }

   getdata()
   {
     this.itmservice.findTax(this.itemnew);
   }

   showitems()
   {
     this.httpobj.getItemdetails().subscribe( 
     (res)=>
     console.log(res)

     );
     
   }
  ngOnInit(): void {
  }

}
