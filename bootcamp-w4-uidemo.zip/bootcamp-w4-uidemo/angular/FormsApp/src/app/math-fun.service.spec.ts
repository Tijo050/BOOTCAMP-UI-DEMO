import { TestBed } from '@angular/core/testing';

import { MathFunService } from './math-fun.service';

describe('MathFunService', () => {
  let service: MathFunService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MathFunService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
