import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpdataService {

 showemployee(dept :string)
 {
   if(dept==="testing")
   alert("Employee shift time 9am to 5pm");
   else if(dept==="development")
   alert("Shift time is 9am to 9pm");
   
 }


  constructor() { }
}
