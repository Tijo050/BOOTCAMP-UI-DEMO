import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UstchildapComponent } from './ustchildap.component';

describe('UstchildapComponent', () => {
  let component: UstchildapComponent;
  let fixture: ComponentFixture<UstchildapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UstchildapComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UstchildapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
