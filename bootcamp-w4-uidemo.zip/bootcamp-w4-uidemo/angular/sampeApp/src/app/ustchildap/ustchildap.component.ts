import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ustchildap',
  templateUrl: './ustchildap.component.html',
  styleUrls: ['./ustchildap.component.css']
})
export class UstchildapComponent implements OnInit {

  @Input()
  apinsurance:string="";
  constructor() { }

  ngOnInit(): void {
  }

}
