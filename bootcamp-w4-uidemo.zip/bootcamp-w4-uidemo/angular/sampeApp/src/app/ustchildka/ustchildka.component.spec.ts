import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UstchildkaComponent } from './ustchildka.component';

describe('UstchildkaComponent', () => {
  let component: UstchildkaComponent;
  let fixture: ComponentFixture<UstchildkaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UstchildkaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UstchildkaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
