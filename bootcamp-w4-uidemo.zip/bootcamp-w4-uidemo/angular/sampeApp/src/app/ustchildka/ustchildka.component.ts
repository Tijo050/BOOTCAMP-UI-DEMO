import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ustchildka',
  templateUrl: './ustchildka.component.html',
  styleUrls: ['./ustchildka.component.css']
})
export class UstchildkaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
