import { Component, OnInit } from '@angular/core';
import { Student } from 'src/student';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  studobj : Student;

  constructor() {

    this.studobj=new Student();

    this.studobj.rollno=0;
    this.studobj.name="Anu";
    this.studobj.mark=90;
   }

  ngOnInit(): void {
    
  }


  display()
  {
    console.log(this.studobj);
  }

}
