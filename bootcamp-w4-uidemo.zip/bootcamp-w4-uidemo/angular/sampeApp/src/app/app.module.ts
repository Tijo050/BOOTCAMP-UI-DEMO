import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HeroComponent } from './hero/hero.component';
import { RegisterComponent } from './register/register.component';
import {FormsModule} from '@angular/forms';
import { StudentComponent } from './student/student.component';
import { UstparentComponent } from './ustparent/ustparent.component';
import { UstchildklComponent } from './ustchildkl/ustchildkl.component';
import { UstchildapComponent } from './ustchildap/ustchildap.component';
import { UstchildkaComponent } from './ustchildka/ustchildka.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HeroComponent,
    RegisterComponent,
    StudentComponent,
    UstparentComponent,
    UstchildklComponent,
    UstchildapComponent,
    UstchildkaComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }


