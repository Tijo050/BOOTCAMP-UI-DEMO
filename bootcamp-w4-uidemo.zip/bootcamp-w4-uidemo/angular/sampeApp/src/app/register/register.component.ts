import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

 name : string = "Arjun";
 state : string = "India";


  constructor() { }

  ngOnInit(): void {
  }
Save()
{
  alert("you clicked save");
}
}
