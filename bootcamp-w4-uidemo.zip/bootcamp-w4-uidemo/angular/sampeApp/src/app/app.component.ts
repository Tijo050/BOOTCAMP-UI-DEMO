import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
   name : string ="Mary";
   title = 'sampeApp';
   age : number=26;

   mycolor : string ="blue";

   courses : string[] = ["cpp","java","asp","dotnet"];

   colors : string[] =["red","blue","green","yello"];

 showAlert() : void
 {
   alert("Welcome");
 }


}
