import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UstparentComponent } from './ustparent.component';

describe('UstparentComponent', () => {
  let component: UstparentComponent;
  let fixture: ComponentFixture<UstparentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UstparentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UstparentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
