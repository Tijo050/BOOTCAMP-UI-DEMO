import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ustparent',
  templateUrl: './ustparent.component.html',
  styleUrls: ['./ustparent.component.css']
})
export class UstparentComponent implements OnInit {

  insurancetype :string="";

  constructor() { 
    this.insurancetype="COVID New";
  }

  ngOnInit(): void {
  }

}
