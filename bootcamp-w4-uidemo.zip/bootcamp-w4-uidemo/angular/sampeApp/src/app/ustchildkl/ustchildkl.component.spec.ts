import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UstchildklComponent } from './ustchildkl.component';

describe('UstchildklComponent', () => {
  let component: UstchildklComponent;
  let fixture: ComponentFixture<UstchildklComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UstchildklComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UstchildklComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
