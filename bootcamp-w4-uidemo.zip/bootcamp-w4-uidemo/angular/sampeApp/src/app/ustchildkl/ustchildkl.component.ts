import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ustchildkl',
  templateUrl: './ustchildkl.component.html',
  styleUrls: ['./ustchildkl.component.css']
})
export class UstchildklComponent implements OnInit {


  @Input()
  klinsurance :string ="";
  constructor() { }

  ngOnInit(): void {
  }

}
