export class Student
{
  rollno:number=0;
   name : string="";
   mark: number=0;
constructor()
{

}

}