import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthorizeService } from './authorize.service';
import { MyrouteService } from './myroute.service';
 
@Injectable({
  providedIn: 'root'
})
export class CanactivatedashGuard implements CanActivate {

  constructor(private authserve : AuthorizeService, private rouservice : MyrouteService)
  {

  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
  
 
  let output=this.authserve.validateToken();
  
  return output
  .then
  (

    (res)=>
      {
        if(!res)
          
          { 
            this.rouservice.openLogin();
           return false;
          }
           else
           return true;
      }
  )

  .catch()

  
  

}

}