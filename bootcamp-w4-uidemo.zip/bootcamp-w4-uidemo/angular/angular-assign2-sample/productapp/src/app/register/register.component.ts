import { Component, OnInit } from '@angular/core';
import { FormControl, Form, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

name : FormControl;
description : FormControl;
price : FormControl;

  constructor() {
this.name=new FormControl('',Validators.required);
this.description=new FormControl('',[Validators.required,Validators.minLength(4)]);
this.price=new FormControl('',Validators.required);

   }

   validateDesc()
   {
     let res="";
     if (this.description.touched && this.description.dirty)
     {
       if (this.description.hasError("minlength"))
        res="Description should be minimum 4 length";
     }
     return res;
   }

validateName()
{
  let result="";
  if(this.name.touched && this.name.invalid)
  {
     result="Name cant be null";
  }

  return result;
}

  ngOnInit(): void {
  }

}
