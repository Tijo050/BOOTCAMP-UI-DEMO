import { TestBed } from '@angular/core/testing';

import { ProductprocessService } from './productprocess.service';

describe('ProductprocessService', () => {
  let service: ProductprocessService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProductprocessService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
