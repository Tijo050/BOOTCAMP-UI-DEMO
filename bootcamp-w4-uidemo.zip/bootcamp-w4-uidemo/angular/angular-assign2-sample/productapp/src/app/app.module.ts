import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
 
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {ReactiveFormsModule} from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import {HttpClientModule} from '@angular/common/http';
import { DashboardComponent } from './dashboard/dashboard.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatFormFieldModule} from '@angular/material/form-field';
 
import {MatCardModule} from '@angular/material/card';
import {FormsModule} from '@angular/forms';


import {RouterModule, Routes} from '@angular/router';
import { CanactivatedashGuard } from './canactivatedash.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

const routes: Routes =[
  {
    path:'login',
    component:LoginComponent
    
  },
 
  {
    path:'dashboard',
    component:DashboardComponent,
   canActivate:[CanactivatedashGuard],
  
   
  },
  {
    path:'',
    redirectTo:'login',
    pathMatch:'full'
  }
  
  
  ]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    MatExpansionModule,
    MatCardModule,
    MatFormFieldModule,
    MatToolbarModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
