import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthorizeService } from '../authorize.service';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

user : FormGroup;
// username : FormControl=;
// password : FormControl=n;
  // username : FormControl=;
  // password : FormControl=n;
  

  constructor(private authserve : AuthorizeService,private myroute : MyrouteService ) {
    
this.user=new FormGroup({
username: new FormControl('',Validators.required),
password: new FormControl('',Validators.minLength(5)),



});

   }

  ngOnInit(): void {
  }

  signIn()
  {
  
   
   this.authserve.connectToserver(this.user.value).subscribe
   (
     (res)=> {
      
        this.authserve.storeToken(res["token"]);
        this.myroute.openDashboard();
        

     }
   )
   
  
  }
}
