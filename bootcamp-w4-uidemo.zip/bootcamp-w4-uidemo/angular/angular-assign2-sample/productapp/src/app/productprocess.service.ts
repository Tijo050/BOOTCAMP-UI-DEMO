import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from 'src/product';
import { AuthorizeService } from './authorize.service';

@Injectable({
  providedIn: 'root'
})
export class ProductprocessService {

  constructor(private httpcli : HttpClient,private authservice : AuthorizeService) { }

  addProduct(productobj : Product) : Observable<Product>
  {
    let tok=this.authservice.getToken();

  return  this.httpcli.post<Product>('http://localhost:3000/api/v1/products',productobj,
  {
    headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
  }
  );

  }

  getProducts() : Observable<Array<Product>>
  {
  let tok=this.authservice.getToken();
   return this.httpcli.get<Array<Product>>('http://localhost:3000/api/v1/products',
   {
    headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
  }
  );
  }
}
