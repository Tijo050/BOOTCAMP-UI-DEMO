import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/Rx';
import { map } from 'rxjs/operators';
 

 

@Injectable({
  providedIn: 'root'
})
export class AuthorizeService {

 data : any;

  constructor(private httpcli : HttpClient) 
  {


   }

   connectToserver(data: any):Observable<any>
   {
     console.log(data);
        return this.httpcli.post('http://localhost:3000/auth/v1',data);
   }

   storeToken(tok:any)
   {
     sessionStorage.setItem("mytoken",tok);
   }

  getToken() :any{
    return sessionStorage.getItem("mytoken");
  }


validateToken() :  Promise<boolean>
{
let tok=this.getToken();

return this.httpcli.post('http://localhost:3000/auth/v1/isAuthenticated', {},
{ headers: new HttpHeaders().set('Authorization', `Bearer ${tok}`) }
) .pipe  //  passing the collection {isAuthenticated:true or false} to pipe & map
(map(
   (res:any) => { return (res["isAuthenticated"]); }) // returning value for key isAuthenticated
).toPromise();
   

 }



}