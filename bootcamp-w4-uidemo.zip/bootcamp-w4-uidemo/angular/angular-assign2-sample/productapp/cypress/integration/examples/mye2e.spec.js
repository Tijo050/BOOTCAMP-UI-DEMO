describe('My First Test', () => {
    it('Visits the home', () => {
      cy.visit('/')
    })

it('check for h1',()=>
{
  cy.get('.clslogin').contains('Login Form')
})



  })


  describe('login page',()=>{

    it('should enter loginid and password ',()=>{
        // cy.get('input[id=username]').type('admin');
        // cy.get('input[id=password]').type('password');
        cy.get('.clsuname').type('admin');
        cy.get('.clspass').type("password");
        cy.wait(4000);
        cy.get('.btnsubmit').click();
        cy.location().should( (location)=> expect(location.href).to.eq('http://localhost:4200/dashboard'));
       // cy.url().should('include','todos');
   
    })

  })