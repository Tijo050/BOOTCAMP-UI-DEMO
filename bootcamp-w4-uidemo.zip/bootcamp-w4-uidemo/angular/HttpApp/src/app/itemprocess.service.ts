import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {  Item } from 'src/item';

@Injectable({
  providedIn: 'root'
})
export class ItemprocessService {

  
  constructor(private httpserveobj : HttpClient) 
  
  
  { }

  additemservice(itemobj : Item) : Observable<Item>
  {
 return this.httpserveobj.post<Item>("http://localhost:3000/item",itemobj);

  }

viewitemservice() :Observable<Array<Item>>
{
 return this.httpserveobj.get<Array<Item>>("http://localhost:3000/item");
}

}
