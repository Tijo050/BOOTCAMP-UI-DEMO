import { Component, OnInit } from '@angular/core';
import { ItemprocessService } from './itemprocess.service';
import { Item } from 'src/item';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'HttpApp';
  items : Array<Item>=[];
  itemnew : Item;
  errmessage :string="";

  constructor(private itemservice : ItemprocessService)
   {
     this.itemnew=new Item();

  }
  ngOnInit() 
  {
     this.itemservice.viewitemservice().subscribe(
       (res)=> {
             this.items=res;
              },
       (err)=>console.log(err)
       
       )
  }

  additem()
  {
    if(this.itemnew.itemname !=null && this.itemnew.id!=null && this.itemnew.itemname!='')
    {
this.itemservice.additemservice(this.itemnew).subscribe(
  res=>{
    console.log("item added" + res)
    this.items.push(res);

  },
  (err)=>{this.errmessage=err.message;}
)
this.itemnew=new Item();
    }
  }
viewitem()
{
 console.log(this.items);
}

}
