function showdetails(event)
{
event.preventDefault();
let tab=document.getElementsByTagName("table")[0];
let tbdy=tab.getElementsByTagName("tbody")[0];
let trows=tbdy.getElementsByTagName("tr");
console.log(trows);
trows[0].style.background="blue";


let str=myform.txtissue.value;


for(i=1;i<trows.length;i++)
{
 let tcells=   trows[i].getElementsByTagName("td");
       let tdarr= [...tcells]; //spread operator
       
       var resultarr=tdarr.filter( td=> td.innerText==str);
  //     console.log(resularr);

       if(resultarr.length>0)
       console.log("Treatment " + trows[i].getElementsByTagName("td")[1].innerText);

}

}