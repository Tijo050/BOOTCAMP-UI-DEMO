var movielist={};

function getMovie(movies)
{
    movielist=movies;
    return movies;
}

function checkMovie(key)
{
    return movielist[key];
}


// {"moviname":"spiderman"}

module.exports={getMovie,checkMovie}