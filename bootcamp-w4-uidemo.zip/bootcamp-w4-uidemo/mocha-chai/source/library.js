

  var booklist=[];
  function loadbooks(books)
  {
      booklist=books;
  };

function isBookAvailable(book)
{
  return booklist.indexOf(book)>=0;
};

function getBookIndexAsync(book,fun){
   setTimeout(
    ()=>{
        fun(booklist.indexOf(book)>=0);
    }

    ,2000
   )
 };



module.exports={loadbooks,isBookAvailable,getBookIndexAsync};