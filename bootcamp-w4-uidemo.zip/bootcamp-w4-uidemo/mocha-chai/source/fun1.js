function  validatePan(pannum)
{
     if(pannum.length<12)
      return false;
      else  
        return true;
}

module.exports=validatePan