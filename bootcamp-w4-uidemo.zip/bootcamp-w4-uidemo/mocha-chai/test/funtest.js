var assert=require('assert')
var expect =require('chai').expect;
var should=require('chai').should();
var fnvalidate=require('../source/fun1')
describe('checking Chai ',function()
{
it('validating pan',function()
{
var res=fnvalidate("ABDi3442");
//assert.equal(false,res);
res.should.equal(false);
}); //it

} //
); //describe