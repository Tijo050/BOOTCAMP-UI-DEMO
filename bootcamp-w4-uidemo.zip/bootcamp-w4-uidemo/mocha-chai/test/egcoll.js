var assert=require('assert')
var coll=require('../source/egcollection');
var should=require('chai').should();

describe('to check collection', () => {
 
    it('test collec',function()
    {
   let movielist={"moviename":"spiderman","director":"Andrew","language":"English"};
   
  resultlist=coll.getMovie(movielist);

resultlist.should.have.property("moviename").equal("spiderman");

//assert.equal(movielist,coll.getMovie(movielist));

//assert.equal("Andrew",coll.checkMovie("director"));
    }) //it 




})
