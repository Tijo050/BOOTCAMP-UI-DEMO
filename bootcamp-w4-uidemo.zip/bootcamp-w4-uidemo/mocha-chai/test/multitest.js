var assert=require('assert');
var fnmulti=require('../source/funMulti')
var expect=require('chai').expect;


describe( ('testing multiplication'),function(){
//    it('check multi',function(){
//     assert.equal(fnmulti(10,20),200);
     
//    })//it

   it('checking multi with chai',()=>{

      var ans=fnmulti(10,40);
      expect(ans).equal(400);
   })



})