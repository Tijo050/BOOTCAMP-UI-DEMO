var assert=require('assert')
var mylibrary=require('../source/library')
beforeEach('initialize' , ()=>
{
    
    mylibrary.loadbooks(['ASP','Python','Java','Angular']);
})

describe('check libraray',()=>{

  describe('check normal function',()=>{
   it('check if book exist',()=>{

    var result=mylibrary.isBookAvailable('ASP');
    assert.equal(result,true);
   })
    }) // describe1

 describe('check async function',()=>{

 it('should check for given book',function(done)
 {
   mylibrary.getBookIndexAsync('ASP', function(myfun)
   
   {
         assert.equal(myfun,true)
   }
   )
 done();
 }) //it
 }); //describe2









}) // describe overall
