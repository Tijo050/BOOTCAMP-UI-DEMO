// function calcuscore(total,score)
// {
//   return total/score;
// }

// let ans=resultDeclare(      function (total,score)
//                         {
//                     return (total/score)*100;
//                         },
//                 480, 500);


//Sample lambda 1
/* function resultDeclare(fun1, x, y)
    {
       console.log("ABC CBSE school");
       return "Your Percentage is " + fun1(x,y);

    }



let ans=resultDeclare( (t,s)=>(t/s)*100
                        ,
                480, 500);

console.log(ans);
*/



// sample lambda2  


let sumall=function (f1,f2, num)
            {
                        // 25 + 125
                return f1(num)+ f2(num);
            }
let ans=sumall( x=>x*x, n=>n*n*n , 5)
console.log(ans)

//sample lambda 3
let result = (m)=>m*m;
console.log(result(10))

//sample lambda 4

let validity= (age)=> {if(age<18)
                     return "Not valid";
                     else
                     return "Valid"
                    }

let res=validity(19)
console.log(res);


//sample lambda5

let changename = (nm)=>console.log(nm.toUpperCase() )

changename("mary");


