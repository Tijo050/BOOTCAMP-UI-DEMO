// first pattern 
//let sqrt=function(x)
//             {
//                     return x*x; 25
//             }

// let cube=function(x)
//             {
//                 return x*x*x; 125
//             }
// let sumall=function (f1,f2, num)
//             {
//                         // 25 + 125
//                 return f1(num)+ f2(num);
//             }
// let ans=sumall(sqrt,cube,5)
// console.log(ans)


//2nd pattern
/* let myfun=function (f1,num)
            {
                                        //100
                return "Answer is " + f1(num);
            }


let ans=myfun( function(x) 
                {
                    return x*x;
                },
                10

            );

console.log(ans);

*/

// Today is 03/june : Welcome or invalid password. 



var overallfun=function( f1,password)
                {
                    console.log("Today is 03/June");
                    f1(password);
                 
                }


overallfun( function(pass)  
{
    if (pass.length<6)
    console.log("Invalid password");
    else
    console.log("Welcome");
}
           ,
            "pass"
        );






