let products=["milk","mango","rice","oil","milkpowder","gas","ribbon", "raddish"]
/*
//traverse

products.forEach( p=>console.log(p));

//map 

let resultarr=products.map ( item=>item.toUpperCase() )

resultarr.forEach( p=>console.log(p));
*/

/* sample filter

let resultfilt=products.filter( itm=> itm.startsWith("m"));
resultfilt.forEach( m=>console.log(m))

*/


/* sample reduce

let output=        products.reduce( (cnt,item)=>
                                     {
                                    if(item.startsWith("r"))
                                    cnt++;
                                    return cnt;
                                    },
                                    0
                                );
console.log("count of items with r is " + output );


let outputarr =     products.reduce ( (oarr,item)=>
                                        {
                                            if(item.startsWith("r"))
                                            oarr.push(item);
                                            return oarr;
                                        },
                                        []
                                        );

outputarr.forEach( itm=> console.log(itm));
*/

//chaining of functions


let cnt=products.map( item => item.toUpperCase())
                .filter( itm=>itm.startsWith("R"))
                .reduce (  (cnt, item) =>{ 
                            cnt++;
                        return cnt;
                              }
                            ,0         
                        )
                                          
console.log("Chaining output " + cnt);


