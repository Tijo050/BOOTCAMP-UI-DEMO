let empdata={"empid":10,"empname":"Paul","salary":2000}
console.log(empdata.empname);
let employees =[
                    {
                        "empid":20,
                        "empname":"Raju"
                    },
                    {
                        "empid":40,
                        "empname":"Arun"
                    },
                    {
                        "empid":50,
                        "empname":"Shankar"
                    }
                ]

// console.log(employees[0].empname);
// employees.forEach( emp => console.log(emp));
//get employee array, whose empid >= 40

let resultarr=employees.filter( emp=>emp.empid>=40 );

resultarr.forEach( a=> console.log(a));


