//function prototype
function fundeduction(fun1,fun2,sal)
{
  //  return calcuPf(5000)+calcuPension(5000);
    return fun1(sal)+fun2(sal);
}
//storing function in a varible
let funpf=function calcuPf(salary)
            {
            return salary*10/100;   
            }
let funpension=function calcuPension(salary)
                {
                if(salary>5000)
                return salary*10/100;
            else
            return salary*5/100;
                }
//let deduction=fundeduction(calcuPf,calcuPension,5000);
let deduction=fundeduction(funpf,funpension,5000);
console.log("Overall deduction is " + deduction);
