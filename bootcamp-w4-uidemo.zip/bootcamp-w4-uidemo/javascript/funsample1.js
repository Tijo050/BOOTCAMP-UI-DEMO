function funFirst()
{
 console.log("Welcome");
}


//calling the function
funFirst();

function funEmployee(salary,name)
{
  console.log("emp name is " + name );
  if(salary<10000)
  console.log("Need to do appraisal review" + salary);
  else
  console.log("Salary is " + (salary+100));
}

funEmployee(17000,"Lalitha")

function funTax(salary)
{
    if(salary<50000)
    return salary*10/100;
    else
    return salary*18/100;
}

//let ans=funTax(30000);
//console.log("Tax is " + ans);

console.log(funTax(30000));