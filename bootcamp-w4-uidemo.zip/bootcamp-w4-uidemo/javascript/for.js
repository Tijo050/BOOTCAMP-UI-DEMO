let n=10;

for(i=0;i<n;i++)
console.log("$")

