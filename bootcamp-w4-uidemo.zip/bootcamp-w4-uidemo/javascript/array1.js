let colors=["red","blue","green","yellow","black","bluishwhite"];

//console.log(colors[0])

let ans=colors.pop();
console.log(ans);

let cnt=colors.push("orange");


for(i=0;i<colors.length;i++)
console.log(colors[i])

console.log("overall count" + cnt)



