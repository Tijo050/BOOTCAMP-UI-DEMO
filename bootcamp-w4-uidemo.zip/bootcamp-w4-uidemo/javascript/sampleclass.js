class Student
{
    rollno=0;
    name="";
    mark="";
    static school="ABC CBSE";
    constructor(rno,nm,mk)
    {
        this.rollno=rno;
        this.name=nm;
        this.mark=mk;
    }   
    getData()
    {
        console.log("name is " + this.name + " rollno " + this.rollno)
    }
};

// let student1=new Student();
// student1.name="mary";


let student1=new Student(100,"Veer",56);
let student2=new Student(200,"Rajiv",68);
let student3=new Student(300,"Munna",98);

let students=[student1,student2,student3]

// console.log(students[2].name);

//students[2].getData();

console.log(Student.school); //static variable using class name


students.filter( e=> e.mark<90).forEach( res=> res.getData())


