const months = ['Jan', 'March', 'April', 'June'];

// splice (starting index, delete count, replacing element)


// months.splice(1, 0, 'Feb');
// months.forEach( m=>console.log(m))


// months.splice(2, 1, 'July');
// months.forEach( m=>console.log(m))

// months.splice(2, 1);
// months.forEach( m=>console.log(m))


let ind=months.findIndex(m=> m=="March");
console.log(ind)
months.splice(ind,2);


months.forEach( m=>console.log(m))





