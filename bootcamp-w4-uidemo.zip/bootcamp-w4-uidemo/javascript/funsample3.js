let funEmpidcheck=function (empid)
                {
             if(empid.startsWith("U"))
             return true;
              else
             return false;
            }
 //  console.log(funEmpcheck("k9383"));
let funAddrcheck=function(addr)
            {
                if(addr.length>8)
                return true;
                else
                return false;
            }
function funoverall(fun1,data)
{
      let ans=fun1(data); // calling  method
      if(ans)
      return "Data is valid" + data ;
      else
      return "Data is invalid" + data;
}
console.log(funoverall(funEmpidcheck,"77874"));
 console.log(funoverall(funAddrcheck,"mainroad,blore"));



