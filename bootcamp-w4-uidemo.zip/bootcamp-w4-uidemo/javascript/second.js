
let n=prompt("Enter your age");

if(n<12)
alert("You are a kid");
else if(n<21)
alert("You are teenager");
else
alert("You are old");
