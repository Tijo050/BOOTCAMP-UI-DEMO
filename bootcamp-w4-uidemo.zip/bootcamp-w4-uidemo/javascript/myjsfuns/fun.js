function display()
{
    alert("Welcome");
}

function changecolor(n)
{

    if(n==1)
    document.getElementsByTagName("section")[0].style.background="red";
    else if (n==2)
    document.getElementsByTagName("section")[0].style.background="blue";
    else
    document.getElementsByTagName("section")[0].style.background="yellow";
}