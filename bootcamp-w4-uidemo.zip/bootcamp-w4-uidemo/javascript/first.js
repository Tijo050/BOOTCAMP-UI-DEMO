
name="Mary"
console.log("Welcome " + name)
// console.log("Address " + addr)

var name;  //hoisting

// let addr="Blore"