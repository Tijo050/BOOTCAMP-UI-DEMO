function printwelcome()
{
    setTimeout( 
        function(x){
        for(let i=0;i<10000;i++)
    console.log("welcome");
        },1000
    )
}

function showData()
{
    console.log("am printing data");
}

function funall()
{
    printwelcome();
    showData();
    console.log("processing main");
}

funall();