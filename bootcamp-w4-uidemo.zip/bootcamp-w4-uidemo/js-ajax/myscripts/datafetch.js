var studentarr=[];
function showData()
{
// event.preventDefault();
fetch("http://localhost:3000/student",{"method":"Get"})
                    .then(
                            (res)=>
                            {
                                if(res.ok)
                                {
                                    console.log("first connect");
                                    console.log(res);
                                    return res.json();
                                    
                                }
                                else
                                console.log("some error");
                            }
                    )
                    .then
                    (
                        (out)=>
                        {
                            console.log("further process");
                            console.log(out);
                            studentarr=out;
                            displayTable();
                        }
                    )

                    .catch(
                        (err)=>
                        console.log("some error")
                    )

}

showData(); //calling the get and load data

function displayTable()
{
    let myoutput="<table border=3><tr><td>id</td><td>Name</td><td>College</td></tr>";

studentarr.forEach(
                     (record)=>
                {
                    myoutput+="<tr>";
 myoutput+="<td>"+record.id+"</td>"+"<td>"+record.name+"</td>"
 +"<td>"+ record.college+"</td>" 
 + "<td> <button onClick=deleteFun('" + record.id + "')>Delete</button></td>" ;
                    myoutput+="</tr>"
               }
 )   
    myoutput+="</table>";
document.getElementById("paraone").innerHTML=myoutput;
}

function deleteFun(sid)
{
    event.preventDefault();
    alert( sid);
   // console.log(`http://localhost:3000/student/${sid}`);

    fetch("http://localhost:3000/student/"+sid,{"method":"DELETE"})
    .then(
        (res)=>console.log("Record deleted")
            
    )
    .catch(
        (err)=>console.log("error")
        )

}

function dataAdd(event)
{
    event.preventDefault();

    console.log("add clicked");

    let sid=frmstudent.txtid.value;
    let sname=frmstudent.txtname.value;
    let clg=frmstudent.txtcollege.value;

    let mydata={
                "id":sid,
                "name":sname,
                "college":clg
    };
    console.log(mydata);
fetch("http://localhost:3000/student",
{
    "method":"post",
    "headers":{"content-type":"application/json"},
    body:JSON.stringify(mydata)
}
).then(
    (res)=>
    {
        if(res.ok)
        {
        studentarr.push(mydata);
        displayTable();
        }
    }
)
.catch(err=>console.log(err))
}