function funpromise()
{
    let age=2;
    let promobj=new Promise ( (resolve,reject)=>
                            {
                                if(age>=10)
                                resolve("You are eligible");
                                else
                                reject("Invalid age");
                            }
    
                            )



    promobj.then( res=> console.log(res))
            .catch( e=> console.log("rejectd - error" + e) )


}

funpromise();
