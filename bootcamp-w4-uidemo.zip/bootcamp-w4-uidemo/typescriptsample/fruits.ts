var fruits : string[] =["apple","mango"];


for(let i=0;i<=2;i++)
console.log(fruits[i]);