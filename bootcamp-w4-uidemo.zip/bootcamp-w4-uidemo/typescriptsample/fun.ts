function checkName(nm : number)
{
   if(nm>10)
     console.log("Welcome");
else
 console.log("Invalid user");


}