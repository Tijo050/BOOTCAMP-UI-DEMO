class Student
{
 rollno : number;
 name :string;

 disp() : void
 {
 console.log("Student object");
 }

}


let stdobj : Student;

stdobj=new Student();

