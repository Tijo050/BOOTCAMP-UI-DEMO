var fruits = ["apple", "mango"];
for (var i = 0; i <= 2; i++)
    console.log(fruits[i]);
