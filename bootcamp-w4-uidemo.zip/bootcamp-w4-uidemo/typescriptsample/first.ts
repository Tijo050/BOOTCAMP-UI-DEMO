var n : number;
n=10;
console.log("Number is" + n);





