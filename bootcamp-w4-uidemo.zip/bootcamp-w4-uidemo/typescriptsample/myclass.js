var Student = /** @class */ (function () {
    function Student() {
    }
    Student.prototype.disp = function () {
        console.log("Student object");
    };
    return Student;
}());
var stdobj;
stdobj = new Student();
