var n;
n = 10;
console.log("Number is" + n);
